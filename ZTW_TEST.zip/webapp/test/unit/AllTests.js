sap.ui.define([
	"ish/med/ZTW_TEST/test/unit/controller/Main.controller"
], function () {
	"use strict";
});